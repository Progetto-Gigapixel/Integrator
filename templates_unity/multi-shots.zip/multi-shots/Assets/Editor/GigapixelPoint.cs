using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

// GIGAPIXEL Editor Punti di interesse - v002 2024-10 - MISTER Smart Innovation

namespace Editor
{
    public class GigapixelPoint : EditorWindow
    {
        public float xTranslateSlider;
        public float yTranslateSlider;
        public float zTranslateSlider;
        public float xRotateSlider;
        public float yRotateSlider;
        public float proportionScale = 0.4f;

        private const float DefaultValue = 0f;
        private const float TrueLightIntensity = 40000f;

        #region Sliders

        private Slider _xTranslateSliderControl;
        private Slider _yTranslateSliderControl;
        private Slider _zTranslateSliderControl;
        private Slider _xRotateSliderControl;
        private Slider _yRotateSliderControl;
        private Slider _lightIntensity;

        private static SliderInt _width;
        private static SliderInt _height;

        #endregion

        #region VisualElements

        private VisualElement _selectSlotFirst;
        private VisualElement _previewZone;
        private VisualElement _previewScreen;
        private VisualElement _blockControls;
        private VisualElement _blockLight;
        private VisualElement _blockImage;
        private VisualElement _editorInteressi;
        private VisualElement _settingsOpera;

        #endregion

        #region Buttons

        private Button _lock1;
        private Button _lock2;
        private Button _lock3;
        private Button _update;
        private Button _integrator;

        #endregion

        #region Toggle/Booleans

        private Toggle _showImage;
        private bool _imageActive;
        private Toggle _wideScreen;
        private Toggle _backface;

        #endregion

        #region TextFields

        private TextField _nomeOpera;
        private TextField _artist;
        private TextField _anno;
        private TextField _desc;
        private TextField _titolo;
        private TextField _descrizioneCam;


        #endregion

        private MinMaxSlider _minMaxZoom;
        private VisualElement _gui;
        private Transform _opera;

        private VisualElement _root;
        private DropdownField _objectSelector;
        private DropdownField _lightSelector;
        private GameObject _cameras;
        private GameObject _lights;
        private int _selectedIndex;
        private int _selectLightIndex;
        private ObjectField _setImage;
        private readonly List<CubeController> _originalTransforms = new();
        private readonly Dictionary<int, Vector3> _savedTranslations = new();
        private readonly Dictionary<int, Vector2> _savedRotations = new();
        private readonly Dictionary<int, float> _lightSettings = new();

        private readonly Dictionary<int, bool> _addImagePoi = new();
        private readonly Dictionary<int, Texture2D> _imageAddedPoi = new();
        private readonly Dictionary<int, string> _titlePoi = new();
        private readonly Dictionary<int, string> _descPoi = new();

        private string _path;

        [MenuItem("Window/Gigapixel")]

        public static void ShowExample()
        {
            var wnd = GetWindow<GigapixelPoint>();
            wnd.titleContent = new GUIContent("Gigapixel");
        }

        private void OnEnable()
        {

            // Trova il root dell'interfaccia
            _root = rootVisualElement;

            // Trova il GameObject parent nella scena
            _cameras = GameObject.Find("Cameras");

            // Trova le luci
            _lights = GameObject.Find("Interactive lights");

            // Check se il GameObject esiste
            if (_cameras)
            {
                foreach (Transform child in _cameras.transform)
                {
                    _originalTransforms.Add(child.GetComponent<CubeController>());
                }
            }
        }

        public void CreateGUI()
        {
            // Clear any existing elements to avoid duplication
            _root.Clear();

            // Instantiate UXML
            var mVisualTreeAsset = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/Editor/GigapixelPoint.uxml");
            VisualElement labelFromUxml = mVisualTreeAsset.Instantiate();
            _root.Add(labelFromUxml);

            #region Find Sliders

            _xTranslateSliderControl = _root.Q<Slider>("xTranslateSlider");
            _yTranslateSliderControl = _root.Q<Slider>("yTranslateSlider");
            _zTranslateSliderControl = _root.Q<Slider>("zTranslateSlider");
            _xRotateSliderControl = _root.Q<Slider>("xRotateSlider");
            _yRotateSliderControl = _root.Q<Slider>("yRotateSlider");
            _lightIntensity = _root.Q<Slider>("intensityLightSlider");

            _width = _root.Q<SliderInt>("OperaWidth");
            _height = _root.Q<SliderInt>("OperaHeight");

            #endregion

            #region Find Toggles

            _wideScreen = _root.Q<Toggle>("wideScreen");
            _showImage = _root.Q<Toggle>("AddImage");
            _backface = _root.Q<Toggle>("BackFace");

            #endregion

            #region Find ViasualElements ("div"s)

            _selectSlotFirst = _root.Q<VisualElement>("SelectSlotFirst");
            _previewZone = _root.Q<VisualElement>("PreviewZone");
            _previewScreen = _root.Q<VisualElement>("VisualPreview");
            _blockControls = _root.Q<VisualElement>("BloccaControlli");
            _blockLight = _root.Q<VisualElement>("BloccaLuci");
            _blockImage = _root.Q<VisualElement>("BloccaImmagine");
            _editorInteressi = _root.Q<VisualElement>("EditorInteressi");
            _settingsOpera = _root.Q<VisualElement>("ImpostazioniOpera");

            #endregion

            #region Find TextBox

            _nomeOpera = _root.Q<TextField>("NomeOpera");
            _artist = _root.Q<TextField>("Autore");
            _anno = _root.Q<TextField>("Anno");
            _desc = _root.Q<TextField>("Desc");
            _titolo = _root.Q<TextField>("Titolo");
            _descrizioneCam = _root.Q<TextField>("DescrizioneCam");

            #endregion

            #region Find Buttons

            var integratorImport = _root.Q<Button>("ImportIntegrator");
            integratorImport.RegisterCallback<ClickEvent>(_ => ImportIntegrator());

            var ripristinaButton = _root.Q<Button>("RipristinaButton");
            ripristinaButton.RegisterCallback<ClickEvent>(_ => {
                zTranslateSlider = xTranslateSlider = yTranslateSlider = xRotateSlider = yRotateSlider = DefaultValue;

                // Update the UI controls to reflect the reset values
                _xTranslateSliderControl.value = xTranslateSlider;
                _yTranslateSliderControl.value = yTranslateSlider;
                _zTranslateSliderControl.value = zTranslateSlider;
                _xRotateSliderControl.value = xRotateSlider;
                _yRotateSliderControl.value = yRotateSlider;

                // Update the cube
                UpdateCube();
                SaveCoord();
            });
            var ripristinaLights = _root.Q<Button>("RipristinaLights");
            ripristinaLights.RegisterCallback<ClickEvent>(_ => {
                _lights.transform.GetChild(_selectLightIndex).GetComponent<Light>().intensity =
                    _lightIntensity.value = DefaultValue;
            });

            var operaOption = _root.Q<Button>("OperaOptions");
            var poiOption = _root.Q<Button>("POIOptions");

            operaOption.RegisterCallback<ClickEvent>(_ => {
                _editorInteressi.style.display = DisplayStyle.None;
                _settingsOpera.style.display = DisplayStyle.Flex;
                operaOption.style.backgroundColor = poiOption.style.color = Color.white;
                poiOption.style.backgroundColor = new Color(0.55f, 0.55f, 0.55f);
                operaOption.style.color = Color.black;
                operaOption.style.unityFontStyleAndWeight = FontStyle.Bold;
                poiOption.style.unityFontStyleAndWeight = FontStyle.Normal;
            });

            poiOption.RegisterCallback<ClickEvent>(_ => {
                _editorInteressi.style.display = DisplayStyle.Flex;
                _settingsOpera.style.display = DisplayStyle.None;
                poiOption.style.backgroundColor = operaOption.style.color = Color.white;
                operaOption.style.backgroundColor = new Color(0.55f, 0.55f, 0.55f);
                poiOption.style.color = Color.black;
                operaOption.style.unityFontStyleAndWeight = FontStyle.Normal;
                poiOption.style.unityFontStyleAndWeight = FontStyle.Bold;
            });

            _lock1 = _root.Q<Button>("ButtonLock1");
            _lock2 = _root.Q<Button>("ButtonLock2");
            _lock3 = _root.Q<Button>("ButtonLock3");
            _lock3.style.backgroundImage = _lock2.style.backgroundImage = _lock1.style.backgroundImage = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Resources/giga-lock-on.png");

            _update = _root.Q<Button>("Aggiorna");

            #endregion

            #region Find Dropdowns

            _objectSelector = _root.Q<DropdownField>("POISelector");
            AddElementInDropdowns( _cameras, _objectSelector);

            _lightSelector = _root.Q<DropdownField>("Preset-luci");
            AddElementInDropdowns(_lights, _lightSelector);

            #endregion

            #region Find Others

            _setImage = _root.Q<ObjectField>("SetImage");
            _minMaxZoom = _root.Q<MinMaxSlider>("ZoomMaxMin");
            //_ui = GameObject.Find("UI").transform;
            _opera = GameObject.Find("Opera").transform;

            _gui = GameObject.Find("UIDocument").GetComponent<UIDocument>().rootVisualElement;

            #endregion

            // Setta il responsive all'avvio della finestra
            DynamicResponsiveWindow();

            // Register value change callbacks
            _root.RegisterCallback<GeometryChangedEvent>(_ => DynamicResponsiveWindow());
            _lock1.RegisterCallback<ClickEvent>(_ => LockClick(_root, _lock1,"BloccaEdit1"));
            _lock2.RegisterCallback<ClickEvent>(_ => LockClick(_root, _lock2, "BloccaEdit2"));
            _lock3.RegisterCallback<ClickEvent>(_ => LockClick(_root, _lock3, "BloccaEdit3"));

            _xTranslateSliderControl.RegisterValueChangedCallback(_ => UpdateCube());
            _xTranslateSliderControl.RegisterCallback<ClickEvent>(_ => SaveCoord());
            _yTranslateSliderControl.RegisterValueChangedCallback(_ => UpdateCube());
            _yTranslateSliderControl.RegisterCallback<ClickEvent>(_ => SaveCoord());
            _zTranslateSliderControl.RegisterValueChangedCallback(_ => UpdateCube());
            _zTranslateSliderControl.RegisterCallback<ClickEvent>(_ => SaveCoord());

            _xRotateSliderControl.RegisterValueChangedCallback(_ => UpdateCube());
            _xRotateSliderControl.RegisterCallback<ClickEvent>(_ => SaveCoord());
            _yRotateSliderControl.RegisterValueChangedCallback(_ => UpdateCube());
            _yRotateSliderControl.RegisterCallback<ClickEvent>(_ => SaveCoord());

            _showImage.RegisterCallback<ClickEvent>(_ => SaveCoord());
            _setImage.RegisterValueChangedCallback(_ => SaveCoord());
            _titolo.RegisterValueChangedCallback(_ => SaveCoord());
            _descrizioneCam.RegisterValueChangedCallback(_ => SaveCoord());

            _width.RegisterValueChangedCallback(_ => {
                _originalTransforms[0].zTranslate = _width.value / 2f / 100f;
                _originalTransforms[2].zTranslate = _width.value / 2f / -100f;
                _originalTransforms[3].zTranslate = _width.value / 2f / 100f;
                _originalTransforms[5].zTranslate = _width.value / 2f / -100f;
                _opera.localScale = new Vector3(_width.value / 1000f, 1f , _height.value / 1000f);
            });
            _width.RegisterCallback<ClickEvent>(_ => LoadCoord());
            _height.RegisterValueChangedCallback(_ => {
                _originalTransforms[0].yTranslate = _originalTransforms[1].yTranslate = _originalTransforms[2].yTranslate = _height.value / 2f / 100f;
                _originalTransforms[3].yTranslate = _originalTransforms[4].yTranslate = _originalTransforms[5].yTranslate = _height.value / 2f / -100f;
                _opera.localScale = new Vector3(_width.value / 1000f, 1f, _height.value / 1000f);
            });
            _height.RegisterCallback<ClickEvent>(_ => LoadCoord());
            _nomeOpera.RegisterValueChangedCallback(_ => {
                _gui.Q<Label>("OperaName").text = _nomeOpera.value;
            });
            _artist.RegisterValueChangedCallback(_ => {
                _gui.Q<Label>("Artist").text = _artist.value;
            });
            _anno.RegisterValueChangedCallback(_ => {
                _gui.Q<Label>("Year").text = _anno.value;
            });
            _desc.RegisterValueChangedCallback(_ => {
                _gui.Q<Label>("Description").text = _desc.value;
            });
            _minMaxZoom.RegisterValueChangedCallback(_ => SetZoomLimits());
            _backface.RegisterValueChangedCallback(_ => {
                var wall1 = GameObject.Find("WallsColliders").GetComponents<BoxCollider>()[2];
                wall1.center = new Vector3(-_minMaxZoom.minValue + (_backface.value ? 100f : 20f), 0f, 0f);
            });

            _wideScreen.RegisterValueChangedCallback(_ => {
                proportionScale = _wideScreen.value ? 0.8f : 0.4f;

                var height = _root.contentRect.height * proportionScale;
                _previewZone.style.height = height;
                _previewScreen.style.width = _root.contentRect.width - 100 <= height + 320 ? _root.contentRect.width - 100 : height + 320;
            });
            _objectSelector.RegisterValueChangedCallback(evt => {
                //SaveCurrentSliderValues();

                _selectedIndex = _objectSelector.choices.IndexOf(evt.newValue);

                _blockControls.style.display = _selectSlotFirst.style.display = _selectedIndex != -1 ? DisplayStyle.None : DisplayStyle.Flex;
                _blockControls.style.visibility = _selectSlotFirst.style.visibility = _selectedIndex != -1 ? Visibility.Hidden : Visibility.Visible;

                foreach (Transform child in _cameras.transform)
                {
                    var isChild = child == _cameras.transform.GetChild(_selectedIndex);
                    child.GetChild(0).GetChild(0).gameObject.SetActive(isChild);
                    child.GetChild(0).GetComponent<Camera>().enabled = isChild;
                }

                LoadSavedSliderValues();

            });
            _lightSelector.RegisterValueChangedCallback(evt => {
                SaveCurrentLightInfos();

                _selectLightIndex = _lightSelector.choices.IndexOf(evt.newValue);
                _blockLight.style.display= _selectLightIndex != -1 ? DisplayStyle.None : DisplayStyle.Flex;
                _blockLight.style.visibility = _selectLightIndex != -1 ? Visibility.Hidden : Visibility.Visible;

                LoadSavedLightInfos();
            });
            _lightIntensity.RegisterValueChangedCallback(_ => {
                _lights.transform.GetChild(_selectLightIndex).GetComponent<Light>().intensity = _lightIntensity.value * TrueLightIntensity;
            });
            _showImage.RegisterValueChangedCallback(evt => {
                _imageActive = evt.newValue;
                _blockImage.style.display = _imageActive ? DisplayStyle.None : DisplayStyle.Flex;
                _blockImage.style.visibility = _imageActive ? Visibility.Hidden : Visibility.Visible;
                _setImage.value = null;
            });
            _setImage.RegisterValueChangedCallback(_ => {
                if (_setImage != null)
                {

                }
            });  // setta l'immagine

            _update.RegisterCallback<ClickEvent>(_ => {
                if (!string.IsNullOrEmpty(_path))
                {
                    var file = File.CreateText(_path);
                    file.WriteLine(_width.value);
                    file.WriteLine(_height.value);
                    file.WriteLine(_nomeOpera.value);
                    file.WriteLine(_artist.value);
                    file.WriteLine(_anno.value);
                    file.WriteLine(_desc.value);
                    file.WriteLine(_backface.value);
                    file.WriteLine(_minMaxZoom.minValue);
                    file.WriteLine(_minMaxZoom.maxValue);
                    file.Close();
                }
                else
                { EditorUtility.DisplayDialog("Errore", "Il file non è stato importato", "OK"); }
            });

            LoadCoord();
        }

        private void ImportIntegrator()
        {
            _path = Application.streamingAssetsPath + "/Info.txt";

            if (!string.IsNullOrEmpty(_path))
            {
                string[] strings = {"Info.txt", "info.txt", "Info.csv", "info.csv"};
                if (strings.Contains(Path.GetFileName(_path)))
                {
                    var lines = File.ReadAllLines(_path);

                    for (var i = 0; i < lines.Length; i++)
                    {
                        if (i == 0) //INT width
                        {
                            if (int.TryParse(lines[i], out var width)) { _width.value = width; }
                            else
                            {
                                EditorUtility.DisplayDialog("Errore", "Valore Larghezza invalido.", "OK");
                                break;
                            }
                        }
                        if (i == 1) //INT height
                        {
                            if (int.TryParse(lines[i], out var height))
                            {
                                _height.value = height;
                                _originalTransforms[0].yTranslate = _height.value/2f/100f;
                                _originalTransforms[0].zTranslate = _width.value/2f/100f;
                                _originalTransforms[1].yTranslate = _height.value/2f/100f;
                                _originalTransforms[2].yTranslate = _height.value/2f/100f;
                                _originalTransforms[2].zTranslate = _width.value/2f/-100f;
                                _originalTransforms[3].yTranslate = _height.value/2f/-100f;
                                _originalTransforms[3].zTranslate = _width.value/2f/100f;
                                _originalTransforms[4].yTranslate = _height.value/2f/-100f;
                                _originalTransforms[5].yTranslate = _height.value/2f/-100f;
                                _originalTransforms[5].zTranslate = _width.value/2f/-100f;
                                LoadCoord();
                            }
                            else
                            {
                                EditorUtility.DisplayDialog("Errore", "Valore Altezza invalido.", "OK");
                                break;
                            }
                        }
                        if (i == 2) //STRING OperaName
                        {
                            if (!string.IsNullOrEmpty(lines[i]))
                            {
                                _gui.Q<Label>("OperaName").text = _nomeOpera.value = lines[i];
                            }
                            else
                            {
                                EditorUtility.DisplayDialog("Errore", "Campo Nome dell'opera senza nome.", "OK");
                                break;
                            }
                        }
                        if (i == 3) //STRING Artist
                        {
                            if (!string.IsNullOrEmpty(lines[i]))
                            {
                                _gui.Q<Label>("Artist").text = _artist.value = lines[i];
                            }
                            else
                            {
                                EditorUtility.DisplayDialog("Errore", "Campo Artista vuoto", "OK");
                                break;
                            }
                        }
                        if (i == 4) //INT Anno
                        {
                            if (int.TryParse(lines[i], out var year))
                            {
                                _gui.Q<Label>("Year").text = _anno.value = year.ToString();
                            }
                            else
                            {
                                EditorUtility.DisplayDialog("Errore", "Anno non valido.", "OK");
                                break;
                            }
                        }
                        if (i == 5) //BOOL front?
                        {
                            string[] validValues = { "True", "true", "sì", "Sì", "Yes", "yes", "y", "Y", "1" };
                            _backface.value = validValues.Contains(lines[i]);
                        }
                        if (i == 6) //INT zoom min limit
                        {
                            if (float.TryParse(lines[i], out var minZoomLimit))
                            {
                                _minMaxZoom.minValue = minZoomLimit;
                                var wall = GameObject.Find("WallsColliders").GetComponents<BoxCollider>()[2];
                                wall.center = new Vector3(-_minMaxZoom.minValue + 20f, 0f, 0f);
                            }
                            else
                            {
                                EditorUtility.DisplayDialog("Errore", "Limite non valido.", "OK");
                                break;
                            }
                        }
                        if (i == 7) //INT zoom max limit
                        {
                            if (float.TryParse(lines[i], out var maxZoomLimit))
                            {
                                _minMaxZoom.maxValue = maxZoomLimit;
                                var wall = GameObject.Find("WallsColliders").GetComponents<BoxCollider>()[3];
                                wall.center = new Vector3(-_minMaxZoom.maxValue - 20f, 0f, 0f);
                            }
                            else
                            {
                                EditorUtility.DisplayDialog("Errore", "Limite non valido.", "OK");
                                break;
                            }
                        }
                        if (i == 8) //STRING Descrizione
                        {
                            var descrizione = string.Join("\n", lines.Skip(8));
                            _gui.Q<Label>("Description").text = _desc.value = descrizione;
                            break;
                        }
                    }

                }
                else { EditorUtility.DisplayDialog("Errore", "Il file selezionato non è valido o non è 'info.txt'.", "OK"); }
            }
        }
        private void SetZoomLimits()
        {
            var wall1 = GameObject.Find("WallsColliders").GetComponents<BoxCollider>()[2];
            wall1.center = new Vector3(-_minMaxZoom.minValue + (_backface.value ? 100f : 20f), 0f, 0f);
            var wall2 = GameObject.Find("WallsColliders").GetComponents<BoxCollider>()[3];
            wall2.center = new Vector3(-_minMaxZoom.maxValue - 20f, 0f, 0f);
        }

        private void DynamicResponsiveWindow()
        {
            float height = _root.contentRect.height * proportionScale;
            _previewZone.style.height = height;

            if (_root.contentRect.width - 100 <= 880)
            {
                if (_root.contentRect.width - 100 <= height + 320)
                {
                    _previewScreen.style.width = _root.contentRect.width - 100;
                }
                _wideScreen.style.display = DisplayStyle.None;
                proportionScale = 0.4f;
                _wideScreen.value = false;
            }
            else
            {
                _previewScreen.style.width = height + 320;
                _wideScreen.style.display = DisplayStyle.Flex;
            }
        }
        private static void AddElementInDropdowns(GameObject container, DropdownField selector)
        {
            var objectNames = (from Transform child in container.transform select child.name).ToList();
            selector.choices = objectNames;
        }
        private static void LockClick(VisualElement root, Button lockButton, string block)
        {
            IStyle blocca1 = root.Q<VisualElement>(block).style;

            if (lockButton.style.backgroundImage == AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Resources/giga-lock-on.png"))
            {
                lockButton.style.backgroundImage = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Resources/giga-lock-off.png");
                lockButton.style.unityBackgroundImageTintColor = new Color(0.7f, 0.7f, 0.7f);
                blocca1.display = DisplayStyle.None;
                blocca1.visibility = Visibility.Hidden;
            }
            else
            {
                lockButton.style.backgroundImage = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Resources/giga-lock-on.png");
                lockButton.style.unityBackgroundImageTintColor = Color.white;
                blocca1.display = DisplayStyle.Flex;
                blocca1.visibility = Visibility.Visible;
            }
        }
        private void UpdateCube()
        {
            if (_selectedIndex >= 0)
            {

                // settaggio nuove coordinate per l'oggetto selezionato
                Vector3 newPosition = new Vector3(_zTranslateSliderControl.value + _originalTransforms[_selectedIndex].xTranslate, _yTranslateSliderControl.value + _originalTransforms[_selectedIndex].yTranslate, _xTranslateSliderControl.value + _originalTransforms[_selectedIndex].zTranslate);

                Quaternion newRotation = Quaternion.Euler(_originalTransforms[_selectedIndex].xRotate + _xRotateSliderControl.value, _originalTransforms[_selectedIndex].yRotate + _yRotateSliderControl.value, 0f);

                // Nuova posizione e rotazione dell'oggetto selezionato
                _cameras.transform.GetChild(_selectedIndex).SetPositionAndRotation(newPosition, newRotation);

                // Forza l'aggiornamento della scena
                EditorApplication.QueuePlayerLoopUpdate();

                // non necessario m_VisualTreeAsset.IMGUIContainer.MarkDirtyRepaint;
                SceneView.RepaintAll();
            }
        }
        private void LoadSavedSliderValues()
        {
            var translationFound = _savedTranslations.TryGetValue(_selectedIndex, out var translation);
            _xTranslateSliderControl.value = translationFound ? translation.x : DefaultValue;
            _yTranslateSliderControl.value = translationFound ? translation.y : DefaultValue;
            _zTranslateSliderControl.value = translationFound ? translation.z : DefaultValue;

            var rotationFound = _savedRotations.TryGetValue(_selectedIndex, out var rotation);
            _xRotateSliderControl.value = rotationFound ? rotation.x : DefaultValue;
            _yRotateSliderControl.value = rotationFound ? rotation.y : DefaultValue;

            var imageFound = _addImagePoi.TryGetValue(_selectedIndex, out var addImage);
            _showImage.value = imageFound && addImage;

            var imageSet = _imageAddedPoi.TryGetValue(_selectedIndex, out var image);
            _setImage.value = imageSet ? image : null;

            var titleFound = _titlePoi.TryGetValue(_selectedIndex, out var titolo);
            _titolo.value = titleFound ? titolo : string.Empty;

            var descFound = _descPoi.TryGetValue(_selectedIndex, out var desc);
            _descrizioneCam.value = descFound ? desc : string.Empty;
        }
        private void SaveCurrentLightInfos()
        {
            if (_selectLightIndex != -1)
            {
                _lightSettings[_selectLightIndex] = _lightIntensity.value;
            }
        }
        private void LoadSavedLightInfos()
        {
            bool dataFound = _lightSettings.TryGetValue(_selectLightIndex, out float data);
            _lightIntensity.value = dataFound ? data : DefaultValue;
        }

        private void SaveCoord()
        {
            if (_selectedIndex != -1)
            {
                _savedTranslations[_selectedIndex] = new Vector3(_xTranslateSliderControl.value, _yTranslateSliderControl.value, _zTranslateSliderControl.value);
                _savedRotations[_selectedIndex] = new Vector2(_xRotateSliderControl.value, _yRotateSliderControl.value);

                _addImagePoi[_selectedIndex] = _showImage.value;
                _imageAddedPoi[_selectedIndex] = _setImage.value as Texture2D;
                _titlePoi[_selectedIndex] = _titolo.value;
                _descPoi[_selectedIndex] = _descrizioneCam.value;
            }

            var path = Path.Combine(Application.streamingAssetsPath, "CameraTransforms.csv");
            using var writer = new StreamWriter(path, false);
            for (var i = 0; i < _cameras.transform.childCount; i++)
            {
                var translation = _savedTranslations.ContainsKey(i) ? _savedTranslations[i] : Vector3.zero;
                var rotation = _savedRotations.ContainsKey(i) ? _savedRotations[i] : Vector2.zero;

                var addImage = _addImagePoi.ContainsKey(i) ? _addImagePoi[i] : false;
                var image = _imageAddedPoi.ContainsKey(i) ? _imageAddedPoi[i] : null;
                var titolo = _titlePoi.ContainsKey(i) ? _titlePoi[i] : string.Empty;
                var desc = _descPoi.ContainsKey(i) ? _descPoi[i] : string.Empty;

                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,  "{0};{1};{2};{3};{4};{5}",
                    i, translation.x, translation.y, translation.z, rotation.x, rotation.y));
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,  "{0};{1};{2};{3};{4}",
                    i +"b",  AssetDatabase.GetAssetPath(image), addImage, titolo, desc));
            }
        }
        private void LoadCoord()
        {
            var path = Path.Combine(Application.streamingAssetsPath, "CameraTransforms.csv");
            if (!File.Exists(path)) return;

            _savedTranslations.Clear();
            _savedRotations.Clear();
            _addImagePoi.Clear();
            _imageAddedPoi.Clear();
            _titlePoi.Clear();
            _descPoi.Clear();

            var lines = File.ReadAllLines(path);
            foreach (var line in lines)
            {
                var parts = line.Split(';');
                if (parts.Length < 6) continue; //check if there are enough lines

                // Check if the line is for attributes (idx+b) or for the camera transforms (idx)
                if (parts[0].EndsWith("b"))
                {
                    var idx = int.Parse(parts[0].TrimEnd('b'));
                    _addImagePoi[idx] = bool.Parse(parts[2]);
                    _imageAddedPoi[idx] = AssetDatabase.LoadAssetAtPath<Texture2D>(parts[1]);
                    _titlePoi[idx] = parts[3];
                    _descPoi[idx] = parts[4];
                }
                else
                {
                    var idx = int.Parse(parts[0]);
                    var tx = float.Parse(parts[1], CultureInfo.InvariantCulture);
                    var ty = float.Parse(parts[2], CultureInfo.InvariantCulture);
                    var tz = float.Parse(parts[3], CultureInfo.InvariantCulture);
                    var rx = float.Parse(parts[4], CultureInfo.InvariantCulture);
                    var ry = float.Parse(parts[5], CultureInfo.InvariantCulture);

                    _savedTranslations[idx] = new Vector3(tx, ty, tz);
                    _savedRotations[idx] = new Vector2(rx, ry);

                    //Aggiorna la posizione e rotazione della telecamera
                    if (_cameras && idx < _cameras.transform.childCount)
                    {
                        var originalPos = _originalTransforms.Count > idx
                            ? new Vector3(_originalTransforms[idx].xTranslate, _originalTransforms[idx].yTranslate,
                                _originalTransforms[idx].zTranslate)
                            : Vector3.zero;
                        var originalRot = _originalTransforms.Count > idx
                            ? new Vector3(_originalTransforms[idx].xRotate, _originalTransforms[idx].yRotate, 0f)
                            : Vector3.zero;
                        var newPos = originalPos + new Vector3(tz, ty, tx);
                        var newRot = Quaternion.Euler(originalRot.x + rx, originalRot.y + ry, 0f);
                        _cameras.transform.GetChild(idx).SetPositionAndRotation(newPos, newRot);
                    }
                }
            }
        }
    }
}