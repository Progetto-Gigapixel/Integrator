using System;
using UnityEditor;
using UnityEngine;
using System.IO;
using UnityEditor.Build.Reporting;

namespace Editor
{
    public static class BuildScript
    {
        [MenuItem("GIGAPIXEL/Build executive Viewer")]
        public static void BuildGame()
        {
            // Imposta le scene da includere nella build
            var scenes = new []
            {
                "Assets/Scene.unity" // <-- sostituisci con le tue scene
            };

            // Percorso di uscita della build
            const string buildPath = "Builds/MyGame.exe"; // Per Windows standalone

            // Assicurati che la directory esista
            var directory = Path.GetDirectoryName(buildPath);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory ?? string.Empty);
            }

            // Opzioni di build
            var buildOptions = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = buildPath,
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.None
            };

            // Esegui la build
            var report = BuildPipeline.BuildPlayer(buildOptions);
            var summary = report.summary;

            switch (summary.result)
            {
                // Risultato
                case BuildResult.Succeeded:
                    Debug.Log($"Build completata con successo: {summary.totalSize / (1024 * 1024)} MB");
                    break;
                case BuildResult.Failed:
                    Debug.LogError("Build fallita");
                    break;
                case BuildResult.Unknown:
                case BuildResult.Cancelled:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}