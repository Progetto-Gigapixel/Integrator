using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Globalization;

public class CameraTransformsLoader : MonoBehaviour
{
    private readonly List<CubeController> _originalTransforms = new();
    private void Start()
    {
        var path = Path.Combine(Application.streamingAssetsPath, "CameraTransforms.csv");

        if (!File.Exists(path)) return;

        foreach (Transform child in transform)
        {
            _originalTransforms.Add(child.GetComponent<CubeController>());
        }

        var lines = File.ReadAllLines(path);
        foreach (var line in lines)
        {
            var parts = line.Split(';');
            if (parts.Length < 6) continue;
            var idx = int.Parse(parts[0]);
            var tx = float.Parse(parts[1], CultureInfo.InvariantCulture);
            var ty = float.Parse(parts[2], CultureInfo.InvariantCulture);
            var tz = float.Parse(parts[3], CultureInfo.InvariantCulture);
            var rx = float.Parse(parts[4], CultureInfo.InvariantCulture);
            var ry = float.Parse(parts[5], CultureInfo.InvariantCulture);

            if (idx < transform.childCount)
            {
                var originalPos = _originalTransforms.Count > idx ? new Vector3(_originalTransforms[idx].xTranslate, _originalTransforms[idx].yTranslate, _originalTransforms[idx].zTranslate) : Vector3.zero;
                var originalRot = _originalTransforms.Count > idx ? new Vector3(_originalTransforms[idx].xRotate, _originalTransforms[idx].yRotate, 0f) : Vector3.zero;

                var newPos = originalPos + new Vector3(tz, ty, tx);
                var newRot = Quaternion.Euler(originalRot.x + rx, originalRot.y + ry, 0f);
                transform.GetChild(idx).SetPositionAndRotation(newPos, newRot);
            }
        }
    }
}