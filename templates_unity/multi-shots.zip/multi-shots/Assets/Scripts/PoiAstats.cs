using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoiAstats : MonoBehaviour
{
    public float xTranslateSlider = 0f;
    public float yTranslateSlider = 0f;
    public float xRotateSlider = 0f;
    public float yRotateSlider = 0f;

    public const float DEFAULT_XTRANSLATE = 0f;
    public const float DEFAULT_YTRANSLATE = 0f;
    public const float DEFAULT_XROTATE = 0f;
    public const float DEFAULT_YROTATE = 0f;

}
