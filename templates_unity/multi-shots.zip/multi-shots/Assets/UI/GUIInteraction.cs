using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

public class GUIInteraction : MonoBehaviour
{
    private HideCameras _switchCamera;
    private VisualElement _root;

    private Button _cam1;
    private Button _cam2;
    private Button _cam3;
    private Button _cam4;
    private Button _cam5;
    private Button _cam6;
    private Button _freeCam;

    private VisualElement _poiInfo;
    private VisualElement _poiPreview;

    private Label _poiTitle;
    private Label _poiDesc;

    private readonly Dictionary<int, bool> _addImagePoi = new();
    private readonly Dictionary<int, Texture2D> _imageAddedPoi = new();
    private readonly Dictionary<int, string> _titlePoi = new();
    private readonly Dictionary<int, string> _descPoi = new();

    private void Awake()
    {
        _root = GetComponent<UIDocument>().rootVisualElement;
    }

    private void OnEnable()
    {
        _switchCamera = GameObject.Find("PlayerCamera").GetComponent<HideCameras>();

        #region Load POI data from CSV file

        var path = Path.Combine(Application.streamingAssetsPath, "CameraTransforms.csv");
        if (!File.Exists(path)) return;

        var lines = File.ReadAllLines(path);
        foreach (var line in lines)
        {
            var parts = line.Split(';');

            if (parts[0].Contains("b"))
            {
                var idx = int.Parse(parts[0].TrimEnd('b'));
                _addImagePoi[idx] = bool.Parse(parts[2]);
                _imageAddedPoi[idx] = Resources.Load<Texture2D>(parts[1]);
                _titlePoi[idx] = parts[3];
                _descPoi[idx] = parts[4];
            }
        }

        #endregion

        #region Load Opera Data from info file

        var info = Application.streamingAssetsPath + "/Info.txt";

        if (!string.IsNullOrEmpty(path))
        {
            var infos = File.ReadAllLines(info);

            for (var i = 0; i < lines.Length; i++)
            {
                if (i == 2) //STRING OperaName
                { _root.Q<Label>("OperaName").text = infos[i]; }
                if (i == 3) //STRING Artist
                { _root.Q<Label>("Artist").text = infos[i]; }
                if (i == 4) //INT Anno
                {
                    if (int.TryParse(infos[i], out var year))
                    {
                        _root.Q<Label>("Year").text = year.ToString();
                    }
                }
                if (i == 8) //STRING Descrizione
                {
                    var descrizione = string.Join("\n", infos.Skip(8));
                    _root.Q<Label>("Description").text = descrizione;
                    break;
                }
            }
        }

        #endregion

        _poiTitle = _root.Q<Label>("PoiTitle");
        _poiDesc = _root.Q<Label>("PoiDescription");

        _poiPreview = _root.Q<VisualElement>("PoiPreview");
        _poiInfo = _root.Q<VisualElement>("POI_Info");

        _cam1 = _root.Q<Button>("Cam1");
        _cam1.clicked += () => { Switch(_cam1,0); };

        _cam2 = _root.Q<Button>("Cam2");
        _cam2.clicked += () => { Switch(_cam2,1); };

        _cam3 = _root.Q<Button>("Cam3");
        _cam3.clicked += () => { Switch(_cam3,2); };

        _cam4 = _root.Q<Button>("Cam4");
        _cam4.clicked += () => { Switch(_cam4,3); };

        _cam5 = _root.Q<Button>("Cam5");
        _cam5.clicked += () => { Switch(_cam5,4); };

        _cam6 = _root.Q<Button>("Cam6");
        _cam6.clicked += () => { Switch(_cam6,5); };

        _freeCam = _root.Q<Button>("FreeCam");
        _freeCam.clicked += () => {

            _switchCamera.FreeCameraMode();
            _poiInfo.RemoveFromClassList("Transition");

        };

    }

    private void Switch(Button cam, int idx)
    {
        _switchCamera.SwitchCameraButton(cam);
        _poiInfo.AddToClassList("Transition");
        _poiTitle.text = _titlePoi[idx];
        _poiDesc.text = _descPoi[idx];
        _poiPreview.style.display = _addImagePoi[idx] ? DisplayStyle.Flex : DisplayStyle.None;
        _poiPreview.style.backgroundImage = new StyleBackground(_imageAddedPoi[idx]);
    }
}