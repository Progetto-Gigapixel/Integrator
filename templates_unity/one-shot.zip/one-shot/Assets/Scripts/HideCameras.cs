using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

public class HideCameras : MonoBehaviour
{
    [SerializeField] public List<GameObject> cameras = new List<GameObject> ();
    private FPSController _control;

    private void Start()
    {
        _control = GetComponent<FPSController>();

        foreach (var cam in cameras)
        {
            cam.SetActive(false);
        }
    }

    private void Update()
    {
        if (Input.anyKeyDown)
        {
            if (Input.inputString == "0")
            {
                FreeCameraMode();
            }
            else
            {
                SwitchCamera();
            }
        }
    }

    private void SwitchCamera()
    {
        foreach (var cam in from cam in cameras let index = cam.name[^1..] where Input.inputString == index select cam)
        {
            _control.AllowMouseControl = _control.canMove = false;
            transform.position = cam.transform.position;
            transform.rotation = cam.transform.rotation;
            break;
        }
    }

    public void SwitchCameraButton(Button b)
    {
        foreach (var cam in from cam in cameras let index = cam.name[^1..] where b.text == index select cam)
        {
            _control.AllowMouseControl = _control.canMove = false;
            transform.position = cam.transform.position;
            transform.rotation = cam.transform.rotation;
            break;
        }
    }

    public void FreeCameraMode()
    {
        _control.AllowMouseControl = _control.canMove = true;
        transform.position = _control.InitialLocation;
        transform.rotation = _control.InitialRotation;
    }
}