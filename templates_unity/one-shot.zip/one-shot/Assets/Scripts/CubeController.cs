using UnityEngine;
// GIGAPIXEL
public class CubeController : MonoBehaviour
{
    public float xTranslate;
    public float yTranslate;
    public float zTranslate;
    public float xRotate;
    public float yRotate;
}