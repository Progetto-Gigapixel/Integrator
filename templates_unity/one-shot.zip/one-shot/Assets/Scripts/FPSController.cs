﻿using System;
using UnityEngine;

public class FPSController : MonoBehaviour

{
    public bool canMove = true;

    [Space(10)]
    [Header("Walk")]
    public float moveSpeed = 6f;

    [Space(10)]
    [Header("Camera Rotation")]
    public float lookSpeed = 2f;
    [Range(45f, 90f)] public float lookXLimit = 45f;
    private float _rotationX;
    private float _rotationY;
    private float _newRotateX;
    private float _newRotateY;
    [Tooltip("Higher value = Less Camera Rotation Lag")] [Range(0f, 50f)] public float rLagSpeed = 0.5f;

    private Rigidbody _rigidbody;
    [NonSerialized] public Vector3 InitialLocation;
    [NonSerialized] public Quaternion InitialRotation;
    [NonSerialized] public bool AllowMouseControl = true;


    // --- Begin ---

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        _rigidbody = GetComponent<Rigidbody>();

        InitialLocation = transform.position;
        InitialRotation = transform.rotation;

    }

    // --- Loop ---

    private void FixedUpdate()
    {
        #region Player Movement

        if (canMove)
        {
            var moveDirection = new Vector3(Input.GetAxis("Horizontal"), Input.GetAxis("Fly"), Input.GetAxis("Vertical"));
            moveDirection = transform.TransformDirection(moveDirection);
            moveDirection.Normalize();

            _rigidbody.MovePosition(_rigidbody.position + moveDirection * (moveSpeed * Time.fixedDeltaTime));
        }

        #endregion
    }

    private void Update()
    {

        // if

        #region Mouse Interact

        if (AllowMouseControl)
        {
            if (Input.GetButton("Fire2"))
            {
                canMove = true;
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
            else
            {
                canMove = false;
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
        }

        #endregion

        //{

        #region Handels Rotation

        if (canMove)
        {
            _rotationX += canMove ? -Input.GetAxis("Mouse Y") * lookSpeed : 0;
            _rotationY += canMove ? Input.GetAxis("Mouse X") * lookSpeed : 0;
            _rotationX = Mathf.Clamp(_rotationX, -lookXLimit, lookXLimit);

            _newRotateX = Mathf.Lerp(_newRotateX, _rotationX, rLagSpeed * Time.deltaTime);
            _newRotateY = Mathf.Lerp(_newRotateY, _rotationY, rLagSpeed * Time.deltaTime);
            transform.rotation = Quaternion.Euler(_newRotateX, _newRotateY + 90f, 0);
        }

        #endregion

    }
}